package cl.esucomex.comanda.servlets;

import cl.esucomex.comanda.servicios.ServicioProducto;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CRUDProductoDelete extends HttpServlet{
    ServicioProducto servProducto = new ServicioProducto();
    
    @Override
    public void doGet (HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        if (servProducto.eliminar(Long.valueOf(req.getParameter("id")))) {
            out.println("<h1>Eliminado</h1>");
        }
        else {
            out.println("<h1 style='color:red'>No se puede eliminar</h1>");
        }
        out.println("<br/><br/><input type='button' value='Volver' onclick='window.location=\"/comanda/crudproducto.do\"'>");
        out.close();
    }
    
}