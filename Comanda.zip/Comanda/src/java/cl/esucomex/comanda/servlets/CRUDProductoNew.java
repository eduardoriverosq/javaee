
package cl.esucomex.comanda.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CRUDProductoNew extends HttpServlet{
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<h1>Nuevo Producto</h1>");
        out.println("<br/><br/>");
        out.println("<form action='new/save.do' method='POST'>");
        out.println("<table>");
        out.println("<tr><td>Descripcion del producto</td><td><input type='text' name='descripcion'/></td></tr>");
        out.println("<tr><td><input type='submit' value='Grabar'/></td></tr>");
        out.println("</table>");
        out.close();
    }
    
}
