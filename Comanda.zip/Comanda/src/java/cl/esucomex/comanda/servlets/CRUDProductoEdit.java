package cl.esucomex.comanda.servlets;
import cl.esucomex.comanda.entidades.Producto;
import cl.esucomex.comanda.servicios.ServicioProducto;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CRUDProductoEdit extends HttpServlet {
    ServicioProducto servProducto = new ServicioProducto();
    
    @Override
    public void doGet (HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        Producto producto = servProducto.consultar(Long.valueOf(req.getParameter("id")));
        if (producto != null) {
            out.println("<h1>Nuevo Producto</h1>");
            out.println("<br/><br/>");
            out.println("<form action='edit/save.do' method='POST'>");
            out.println("<table>");
            out.println("<tr><td>Id</td><td><input type='text' name='id' value='" + producto.getId() + "' readonly/></td></tr>");
            out.println("<tr><td>Descripcion</td><td><input type='text' name='descripcion' value='" + producto.getDescripcion() + "'/></td></tr>");
            out.println("<tr><td><input type='submit' value='Grabar'/></td></tr>");
            out.println("</table>");
        }
        else {
            out.println("<h1>No se puede recuperar el producto</h1>");
        }
        out.close();
    }
    
}
