
package cl.esucomex.comanda.servlets;

import cl.esucomex.comanda.entidades.Tipo;
import cl.esucomex.comanda.servicios.ServicioTipo;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CRUDTipoNewSave extends HttpServlet {
    private ServicioTipo servTipo = new ServicioTipo();
    
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        Tipo tipo = servTipo.insertar(new Tipo(null,req.getParameter("descripcion")));
        if (tipo != null) {
            out.println("<h1>Nuevo tipo creado</h1>");
            out.println("<table>");
            out.println("<tr><td>Id</td><td>" + tipo.getId() + "</td></tr>");
            out.println("<tr><td>Descripcion</td><td>" + tipo.getDescripcion() +"</td></tr>");
            out.println("</table>");
        }
        else {
            out.println("<h1>Error al crear nuevo tipo</h1>");
        }
        out.close();
    }
}
