
package cl.esucomex.comanda.servlets;

import cl.esucomex.comanda.entidades.Producto;
import java.io.IOException;
import cl.esucomex.comanda.servicios.ServicioProducto;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CRUDProducto extends HttpServlet {

    private ServicioProducto ServProducto = new ServicioProducto();

    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        List<Producto> productos = ServProducto.listar();
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<script>function eliminar(id) {if (confirm('Desea eliminar?')) window.location=\"crudproducto/delete.do?id=\" + id;}</script>");
        out.println("<h1>Productos</h1>");
        out.println("<br/><br/>");
        out.println("<input type='button' value='Nuevo' onclick='window.location=\"crudproducto/new.do\"'/>");
        out.println("<select>");
        out.println("<option>1</option>");
        out.println("<option>2</option>");
        out.println("<option>3/option>");
       out.println("</select>");

        out.println("<table><tr><th>ID</th><th>Nombre</th><th>acciones</th></tr>");
        for (Producto producto : productos) {
            out.print("<tr><td>" + producto.getId() + "</td>");
            out.print("<td>" + producto.getDescripcion() + "</td>");
            out.print("<td><input type='button' value='Modificar' onclick='window.location=\"crudproducto/edit.do?id=" + producto.getId() + "\"'/>&nbsp;");
            out.println("<input type='button' value='Eliminar' onclick='eliminar(" + producto.getId() + ")'/></td></tr>");
        }

        out.println("</table>");
        String hola = null;
        out.close();
    }
}
