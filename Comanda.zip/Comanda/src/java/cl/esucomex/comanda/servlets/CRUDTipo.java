

package cl.esucomex.comanda.servlets;

import cl.esucomex.comanda.entidades.Tipo;
import cl.esucomex.comanda.servicios.ServicioTipo;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CRUDTipo extends HttpServlet {
    private ServicioTipo servTipo = new ServicioTipo();
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        List<Tipo> tipos = servTipo.listar();
        
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<script>function eliminar(id) {if (confirm('Desea eliminar?')) window.location=\"crudtipo/delete.do?id=\" + id;}</script>");
        out.println("<h1>tipos</h1>");
        out.println("<br/><br/>");
        out.println("<input type='button' value='Nuevo' onclick='window.location=\"crudtipo/new.do\"'/>");
        out.println("<table><tr><th>ID</th><th>Descripcion</th><th>acciones</th></tr>");
        for (Tipo tipo : tipos) {
            out.print("<tr><td>" + tipo.getId() + "</td>");
            out.print("<td>" + tipo.getDescripcion() + "</td>");
            out.print("<td><input type='button' value='Modificar' onclick='window.location=\"crudtipo/edit.do?id=" + tipo.getId() + "\"'/>&nbsp;");
            out.println("<input type='button' value='Eliminar' onclick='eliminar(" + tipo.getId() + ")'/></td></tr>");
        }
        out.println("</table>");
        String hola = null;
        out.close();
    }
}
