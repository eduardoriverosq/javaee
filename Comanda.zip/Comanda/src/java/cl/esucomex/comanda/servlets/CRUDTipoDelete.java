
package cl.esucomex.comanda.servlets;

import cl.esucomex.comanda.entidades.Tipo;
import cl.esucomex.comanda.servicios.ServicioTipo;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CRUDTipoDelete extends HttpServlet {
    ServicioTipo servTipo = new ServicioTipo();
    
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        if (servTipo.eliminar(Long.valueOf(req.getParameter("id")))) {
            out.println("<h1>Eliminacion correcta</h1>");
        }
        else {
            out.println("<h1 style='color:red'>Problemas al eliminar el tipo</h1>");
        }
        out.println("<br/><br/><input type='button' value='Volver' onclick='window.location=\"/comanda/crudtipo.do\"'>");
        out.close();
    }
}
