
package cl.esucomex.comanda.servicios;

import cl.esucomex.comanda.entidades.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;


public class ServicioProducto implements InterfazCrud<Producto, Long> {

    @Override
    public Producto insertar(Producto entidad) {
        Connection cn = null;
        PreparedStatement sti = null;
        PreparedStatement sts = null;
        ResultSet rs = null;
        try {
            cn = BaseDeDatos.getConnection();
            sti = cn.prepareStatement("insert into producto (nombre, descripcion, codigo_barra, id_tipo) values (?,?,?,?)");
            sti.setString(1, entidad.getNombre());
            sti.setString(2, entidad.getDescripcion());
            sti.setString(3, entidad.getCodigoBarra());
            sti.setLong(4, entidad.getIdTipo());
            sti.execute();
            if (sti.getUpdateCount() == 0) {
                System.err.println("Error al grabar el tipo " + entidad);
            }
            else {
                sts = cn.prepareStatement("select * from tipo where descripcion = ?");
                sts.setString(1, entidad.getDescripcion());
                rs = sts.executeQuery();
                if (rs.next()) {
                    entidad.setId(rs.getLong("id"));
                    return entidad;
                }
                else {
                    System.err.println("Error al recuperar el tipo " + entidad);
                }
                return null;
            }
        }
        catch (Exception ex) {
            System.err.println("Error al grabar el tipo " + entidad);
        }
        finally {
            try {if (rs != null) rs.close();} catch (Exception e) {}
            try {if (sts != null) sts.close();} catch (Exception e) {}
            try {if (sti != null) sti.close();} catch (Exception e) {}
            try {if (cn != null) cn.close();} catch (Exception e) {}
        }
        return null;
    }

    @Override
    public Producto consultar(Long llave) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Producto actualizar(Producto entidad) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean eliminar(Long llave) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Producto> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
