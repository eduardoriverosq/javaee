
package cl.esucomex.comanda.servicios;

import java.util.List;


public interface InterfazCrud<T, K> {
    public T insertar(T entidad);
    public T consultar(K llave);
    public T actualizar(T entidad);
    public boolean eliminar(K llave);
    public List<T> listar();
}
