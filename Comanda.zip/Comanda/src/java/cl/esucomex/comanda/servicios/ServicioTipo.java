
package cl.esucomex.comanda.servicios;

import cl.esucomex.comanda.entidades.Tipo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class ServicioTipo implements InterfazCrud<Tipo, Long> {

    @Override
    public Tipo insertar(Tipo entidad) {
        Connection cn = null;
        PreparedStatement sti = null;
        PreparedStatement sts = null;
        ResultSet rs = null;
        try {
            cn = BaseDeDatos.getConnection();
            sti = cn.prepareStatement("insert into tipo (descripcion) values (?)");
            sti.setString(1, entidad.getDescripcion());
            sti.execute();
            if (sti.getUpdateCount() == 0) {
                System.err.println("Error al grabar el tipo " + entidad);
            }
            else {
                sts = cn.prepareStatement("select * from tipo where descripcion = ?");
                sts.setString(1, entidad.getDescripcion());
                rs = sts.executeQuery();
                if (rs.next()) {
                    entidad.setId(rs.getLong("id"));
                    return entidad;
                }
                else {
                    System.err.println("Error al recuperar el tipo " + entidad);
                }
                return null;
            }
        }
        catch (Exception ex) {
            System.err.println("Error al grabar el tipo " + entidad);
        }
        finally {
            try {if (rs != null) rs.close();} catch (Exception e) {}
            try {if (sts != null) sts.close();} catch (Exception e) {}
            try {if (sti != null) sti.close();} catch (Exception e) {}
            try {if (cn != null) cn.close();} catch (Exception e) {}
        }
        return null;
    }

    @Override
    public Tipo consultar(Long llave) {
        Connection cn = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        Tipo tipo = null;
        try {
            cn = BaseDeDatos.getConnection();
            st = cn.prepareStatement("select * from tipo where id = ?");
            st.setLong(1, llave);
            rs = st.executeQuery();
            if (rs.next()) {
                tipo = new Tipo(rs.getLong("id"), rs.getString("descripcion"));
            }
        }
        catch (Exception ex) {
            System.err.println("Error al consultar el tipo " + llave);
        }
        finally {
            try {if (rs != null) rs.close();} catch (Exception e) {}
            try {if (st != null) st.close();} catch (Exception e) {}
            try {if (cn != null) cn.close();} catch (Exception e) {}
        }
        return tipo;
    }

    @Override
    public Tipo actualizar(Tipo entidad) {
        Connection cn = null;
        PreparedStatement st = null;
        try {
            cn = BaseDeDatos.getConnection();
            st = cn.prepareStatement("update tipo  set descripcion = ? where id = ?");
            st.setString(1, entidad.getDescripcion());
            st.setLong(2, entidad.getId());
            st.execute();
            if (st.getUpdateCount() == 0) {
                System.err.println("Error al grabar el tipo " + entidad);
            }
            else {
                return entidad;
            }
        }
        catch (Exception ex) {
            System.err.println("Error al grabar el tipo " + entidad);
        }
        finally {
            try {if (st != null) st.close();} catch (Exception e) {}
            try {if (cn != null) cn.close();} catch (Exception e) {}
        }
        return consultar(entidad.getId());
    }

    @Override
    public boolean eliminar(Long llave) {
        Connection cn = null;
        PreparedStatement st = null;
        try {
            cn = BaseDeDatos.getConnection();
            st = cn.prepareStatement("delete from tipo where id = ?");
            st.setLong(1, llave);
            st.execute();
            if (st.getUpdateCount() == 0) {
                System.err.println("Error al eliminar el tipo " + llave);
            }
            else {
                return true;
            }
        }
        catch (Exception ex) {
            System.err.println("Error al eliminar el tipo " + llave);
        }
        finally {
            try {if (st != null) st.close();} catch (Exception e) {}
            try {if (cn != null) cn.close();} catch (Exception e) {}
        }
        return false;
    }

    @Override
    public List<Tipo> listar() {
        Connection cn = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        List<Tipo> tipos = new ArrayList<Tipo>();
        try {
            cn = BaseDeDatos.getConnection();
            st = cn.prepareStatement("select * from tipo");
            rs = st.executeQuery();
            while (rs.next()) {
                Tipo tipo = new Tipo();
                tipo.setId(rs.getLong("id"));
                tipo.setDescripcion(rs.getString("descripcion"));
                tipos.add(tipo);
            }
        }
        catch (Exception ex) {
            System.err.println("Error al consultar el tipo");
        }
        finally {
            try {if (rs != null) rs.close();} catch (Exception e) {}
            try {if (st != null) st.close();} catch (Exception e) {}
            try {if (cn != null) cn.close();} catch (Exception e) {}
        }
        return tipos;
    }
}
