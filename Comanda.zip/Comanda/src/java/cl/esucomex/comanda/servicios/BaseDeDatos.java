
package cl.esucomex.comanda.servicios;

import java.sql.Connection;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class BaseDeDatos {
    private static DataSource dataSource;
    
    static {
        try {
            dataSource = (DataSource) new InitialContext().lookup("jdbc/db");
        }
        catch (Exception e) {
            System.err.println("Error al buscar el recurso base de datos");
        }
    }
    
    public static Connection getConnection() {
        try {
            return dataSource.getConnection();
        }
        catch (Exception e) {
            System.err.println("Error al obtener conexion a la base de datos");
            return null;
        }
    }
}
