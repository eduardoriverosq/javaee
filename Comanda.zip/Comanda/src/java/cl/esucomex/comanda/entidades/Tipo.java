
package cl.esucomex.comanda.entidades;


public class Tipo {
    private Long id;
    private String descripcion;

    public Tipo() {
    }

    public Tipo(Long id, String descripcion) {
        this.id = id;
        this.descripcion = descripcion;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id != null && id > 0) {
            this.id = id;
        }
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        if (descripcion != null && descripcion.length() <= 50 ) {
            this.descripcion = descripcion;
        }
    }

    @Override
    public int hashCode() {
        int hash = "TIPO".hashCode();
        hash = hash + (this.id != null ? this.id.hashCode() : 0) + (this.descripcion != null ? this.descripcion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Tipo other = (Tipo) obj;
        if (this.id != other.id && (this.id == null || !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Tipo{" + "id=" + id + ", descripcion=" + descripcion + '}';
    }
}
